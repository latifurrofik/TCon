# TCon — GitHub Actions YouTube Agent

Automasi awal untuk mengganti n8n dengan GitHub Actions:
- riset ide dan draft YouTube Shorts melalui Gemini API;
- upload video yang sudah jadi ke YouTube melalui YouTube Data API;
- menyimpan laporan upload sebagai workflow artifact.

## Batasan
GitHub Actions tidak otomatis menghasilkan file video. Untuk full otomatis sampai video jadi, perlu layanan generator video dengan API yang dapat diakses workflow. Google Flow tidak diasumsikan punya API publik yang bisa dipanggil di sini.

## Setup
1. Di GitHub buka **Settings → Secrets and variables → Actions**.
2. Tambahkan secret `GEMINI_API_KEY` dari Google AI Studio.
3. Tambahkan secret `YOUTUBE_TOKEN_JSON` berisi seluruh isi `token.json` OAuth yang memiliki scope `https://www.googleapis.com/auth/youtube.upload`.
4. Buka tab **Actions**, jalankan workflow **TCon YouTube Agent** lewat **Run workflow**.

Workflow terjadwal setiap hari menjalankan riset dan menyimpan JSON sebagai artifact. Untuk upload, jalankan manual dan isi HTTPS direct-download URL video, judul, deskripsi, tag. URL video harus berupa tautan unduhan langsung tanpa login.

Upload default adalah **unlisted**. Pilih `public` hanya jika memang ingin langsung dipublikasikan. Periksa isi video, hak penggunaan, dan metadata sebelum publikasi.

## Catatan
- Jangan commit API key, OAuth token, atau video privat ke repository.
- GitHub Actions memakai runner sementara; file lokal tidak otomatis tersedia pada run berikutnya.
- Laporan upload dan draft tersedia pada artifact workflow selama 30 hari.
