from __future__ import annotations
import argparse, json, os, re, sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import requests
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

OUTPUT, REPORTS = Path('output'), Path('reports')
SCOPES = ['https://www.googleapis.com/auth/youtube.upload']
VIDEO_EXTENSIONS = {'.mp4', '.mov', '.m4v', '.webm', '.mkv'}

def gemini_generate(prompt: str) -> str:
    key = os.environ.get('GEMINI_API_KEY')
    if not key: raise RuntimeError('Secret GEMINI_API_KEY belum diatur.')
    model = os.environ.get('GEMINI_MODEL', 'gemini-2.5-flash')
    response = requests.post(f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent', params={'key': key}, json={'contents':[{'parts':[{'text':prompt}]}], 'generationConfig':{'temperature':0.7,'responseMimeType':'application/json'}}, timeout=120)
    response.raise_for_status()
    data = response.json()
    try: return data['candidates'][0]['content']['parts'][0]['text']
    except (KeyError, IndexError, TypeError) as exc: raise RuntimeError(f'Respons Gemini tidak sesuai format: {data}') from exc

def research() -> dict:
    prompt = '''Create one English YouTube Shorts content idea for a global audience in AI facts, misconceptions, or everyday technology. Prefer evergreen curiosity topics. Do not claim current news or precise statistics without a verification note. Return valid JSON only with keys: topic, angle, fact_check_notes (array), title (max 70 chars), hook (max 12 words), script (25-40 sec voice-over), visual_plan (5-7 shot array), description, hashtags (3-5 array), tags (5-12 array). Clearly mark facts needing independent verification.'''
    raw = gemini_generate(prompt)
    try: data = json.loads(raw)
    except json.JSONDecodeError:
        match = re.search(r'\{.*\}', raw, re.S)
        if not match: raise RuntimeError('Gemini tidak mengembalikan JSON valid.')
        data = json.loads(match.group(0))
    data['created_at_utc'] = datetime.now(timezone.utc).isoformat()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    path = OUTPUT / f'research-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}.json'
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return data

def youtube_service():
    raw = os.environ.get('YOUTUBE_TOKEN_JSON')
    if not raw: raise RuntimeError('Secret YOUTUBE_TOKEN_JSON belum diatur.')
    try: info = json.loads(raw)
    except json.JSONDecodeError as exc: raise RuntimeError('YOUTUBE_TOKEN_JSON harus berisi JSON token.json valid.') from exc
    creds = Credentials.from_authorized_user_info(info, SCOPES)
    if creds.expired and creds.refresh_token: creds.refresh(Request())
    if not creds.valid: raise RuntimeError('OAuth token tidak valid; buat ulang token dengan scope youtube.upload.')
    return build('youtube', 'v3', credentials=creds, cache_discovery=False)

def download_video(url: str) -> Path:
    parsed = urlparse(url)
    if parsed.scheme != 'https' or not parsed.netloc: raise ValueError('URL video harus HTTPS direct-download URL.')
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with requests.get(url, stream=True, timeout=(20,180), allow_redirects=True) as r:
        r.raise_for_status()
        ctype = r.headers.get('Content-Type','').lower()
        ext = Path(urlparse(r.url).path).suffix.lower()
        if ext not in VIDEO_EXTENSIONS:
            if 'mp4' in ctype or 'octet-stream' in ctype: ext = '.mp4'
            elif 'webm' in ctype: ext = '.webm'
            else: raise ValueError(f'URL tidak tampak seperti file video (Content-Type: {ctype}).')
        target, size = OUTPUT / f'upload-video{ext}', 0
        with target.open('wb') as f:
            for chunk in r.iter_content(1024*1024):
                if chunk:
                    size += len(chunk)
                    if size > 1_800_000_000: raise ValueError('Video melebihi batas aman 1.8 GB untuk runner ini.')
                    f.write(chunk)
    if size == 0: raise ValueError('File video kosong.')
    print(f'Video diunduh: {target} ({size} bytes)')
    return target

def upload_video(path: Path, title: str, description: str, tags: list[str], visibility: str) -> dict:
    if not title.strip(): raise ValueError('Judul tidak boleh kosong.')
    if visibility not in {'private','unlisted','public'}: raise ValueError('Visibility tidak valid.')
    body = {'snippet': {'title':title[:100], 'description':description[:5000], 'tags':[x[:100] for x in tags[:30]], 'categoryId':'28'}, 'status': {'privacyStatus':visibility, 'selfDeclaredMadeForKids':False}}
    req = youtube_service().videos().insert(part='snippet,status', body=body, media_body=MediaFileUpload(str(path), chunksize=8*1024*1024, resumable=True))
    response = None
    while response is None:
        status, response = req.next_chunk()
        if status: print(f'Upload progress: {int(status.progress()*100)}%')
    vid = response['id']
    return {'video_id':vid,'url':f'https://www.youtube.com/watch?v={vid}','title':title,'visibility':visibility,'uploaded_at_utc':datetime.now(timezone.utc).isoformat()}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--mode', choices=['research','upload','research_upload'], default='research')
    p.add_argument('--video-url', default=''); p.add_argument('--title', default=''); p.add_argument('--description', default=''); p.add_argument('--tags', default=''); p.add_argument('--visibility', choices=['private','unlisted','public'], default='unlisted')
    a=p.parse_args()
    if a.mode in {'research','research_upload'}: research()
    if a.mode in {'upload','research_upload'}:
        if not a.video_url: raise ValueError('Mode upload memerlukan --video-url.')
        if not a.title.strip(): raise ValueError('Mode upload memerlukan --title.')
        result=upload_video(download_video(a.video_url),a.title,a.description,[x.strip() for x in a.tags.split(',') if x.strip()],a.visibility)
        REPORTS.mkdir(parents=True,exist_ok=True)
        report=REPORTS/f'upload-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}.json'
        report.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print('UPLOAD_REPORT='+json.dumps(result,ensure_ascii=False))
if __name__=='__main__':
    try: main()
    except Exception as e: print(f'ERROR: {e}',file=sys.stderr); sys.exit(1)
